﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows.Forms;
using WindowsFormsApp2;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        private Form1 form1;

        [TestInitialize]
        public void Setup()
        {
            form1 = new Form1();
        }

        [TestMethod]
        public void TextBox2_TextChanged_ShouldMaskPassword()
        {
            // Arrange
            form1.textBox2.Text = "password";

            // Act
            form1.textBox2_TextChanged(null, EventArgs.Empty);

            // Assert
            Assert.IsTrue(form1.textBox2.UseSystemPasswordChar);
        }

        [TestMethod]
        public void Button1_Click_EmptyLogin_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "";
            form1.textBox2.Text = "password";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }

        [TestMethod]
        public void Button1_Click_EmptyPassword_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "login";
            form1.textBox2.Text = "";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }

        [TestMethod]
        public void Button1_Click_InvalidCredentials_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "invalidLogin";
            form1.textBox2.Text = "invalidPassword";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }

        [TestMethod]
        public void Button1_Click_ValidCredentials_ShouldOpenForm2()
        {
            // Arrange
            form1.textBox1.Text = "validLogin";
            form1.textBox2.Text = "validPassword";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на открытие Form2
        }

        [TestMethod]
        public void Button1_Click_NewUser_ShouldRegisterAndOpenForm2()
        {
            // Arrange
            form1.textBox1.Text = "newLogin";
            form1.textBox2.Text = "newPassword";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на регистрацию и открытие Form2
        }

        [TestMethod]
        public void Button1_Click_ExistingUser_ShouldNotRegister()
        {
            // Arrange
            form1.textBox1.Text = "existingLogin";
            form1.textBox2.Text = "existingPassword";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }

        [TestMethod]
        public void Button1_Click_EmptyLoginAndPassword_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "";
            form1.textBox2.Text = "";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }

        [TestMethod]
        public void Button1_Click_WhitespaceLogin_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "   ";
            form1.textBox2.Text = "password";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибкеперд
        }

        [TestMethod]
        public void Button1_Click_WhitespacePassword_ShouldShowErrorMessage()
        {
            // Arrange
            form1.textBox1.Text = "login";
            form1.textBox2.Text = "   ";

            // Act
            form1.button1_Click(null, EventArgs.Empty);

            // Assert
            // Проверка на наличие сообщения об ошибке
        }
    }
}
