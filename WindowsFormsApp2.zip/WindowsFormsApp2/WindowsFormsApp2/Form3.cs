﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";

        public Form3()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void LoadData()
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole != "Admin" && currentRole != "Kassir")
            {
                tabControl7.Hide();
            }

            // Книги
            string query = "SELECT * FROM Управленцы";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void жанрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Управленцы (ФИО, Должность, Номер_телефона, Email, Логин, Пароль, Роль, ID_спектакля) VALUES (@ФИО, @Должность, @Номер_телефона, @Email, @Логин, @Пароль, @Роль, @ID_спектакля)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ФИО", textBox28.Text);
                    command.Parameters.AddWithValue("@Должность", textBox34.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox33.Text);
                    command.Parameters.AddWithValue("@Email", textBox35.Text);
                    command.Parameters.AddWithValue("@Логин", textBox1.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox2.Text);
                    command.Parameters.AddWithValue("@Роль", textBox3.Text);
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox4.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Управленцы SET ФИО = @ФИО, Должность = @Должность, Номер_телефона = @Номер_телефона, Email = @Email, Логин = @Логин, Пароль = @Пароль, Роль = @Роль, ID_спектакля = @ID_спектакля WHERE ID_работник = @ID_работник";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_работник", int.Parse(textBox10.Text));
                    command.Parameters.AddWithValue("@ФИО", textBox11.Text);
                    command.Parameters.AddWithValue("@Должность", textBox12.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox9.Text);
                    command.Parameters.AddWithValue("@Email", textBox13.Text);
                    command.Parameters.AddWithValue("@Логин", textBox8.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox7.Text);
                    command.Parameters.AddWithValue("@Роль", textBox6.Text);
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox5.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Управленцы WHERE ID_работник = @ID_работник";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_работник", int.Parse(textBox32.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void FilterDataByBook()
        {
            string filterValueID = textBox19.Text.Trim();
            string filterValueFIO = textBox20.Text.Trim();
            string filterValuePosition = textBox21.Text.Trim();
            string filterValuePhone = textBox18.Text.Trim();
            string filterValueEmail = textBox22.Text.Trim();
            string filterValueLogin = textBox17.Text.Trim();
            string filterValuePassword = textBox16.Text.Trim();
            string filterValueRole = textBox15.Text.Trim();
            string filterValueSpectacleID = textBox14.Text.Trim();

            string query = @"SELECT * FROM Управленцы WHERE 1=1";

            if (!string.IsNullOrEmpty(filterValueID) && int.TryParse(filterValueID, out int id))
            {
                query += $" AND ID_работник = {id}";
            }

            if (!string.IsNullOrEmpty(filterValueFIO))
            {
                query += $" AND ФИО LIKE '%{filterValueFIO}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePosition))
            {
                query += $" AND Должность LIKE '%{filterValuePosition}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePhone))
            {
                query += $" AND Номер_телефона LIKE '%{filterValuePhone}%'";
            }

            if (!string.IsNullOrEmpty(filterValueEmail))
            {
                query += $" AND Email LIKE '%{filterValueEmail}%'";
            }

            if (!string.IsNullOrEmpty(filterValueLogin))
            {
                query += $" AND Логин LIKE '%{filterValueLogin}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePassword))
            {
                query += $" AND Пароль LIKE '%{filterValuePassword}%'";
            }

            if (!string.IsNullOrEmpty(filterValueRole))
            {
                query += $" AND Роль LIKE '%{filterValueRole}%'";
            }

            if (!string.IsNullOrEmpty(filterValueSpectacleID) && int.TryParse(filterValueSpectacleID, out int spectacleID))
            {
                query += $" AND ID_спектакля = {spectacleID}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FilterDataByBook();
        }

        private void личныйКабинетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
