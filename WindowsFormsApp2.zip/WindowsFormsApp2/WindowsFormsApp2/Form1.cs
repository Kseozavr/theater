﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        public void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }

        public void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, введите логин и пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Роль FROM Управленцы WHERE Логин = @Login AND Пароль = @Password UNION ALL SELECT Роль FROM Клиенты WHERE Логин = @Login AND Пароль = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);

                    connection.Open();
                    object role = command.ExecuteScalar();
                    if (role != null)
                    {
                        string userRole = (string)role;
                        UserManager.SetCurrentUser(login, userRole);

                        Form2 form2 = new Form2();
                        form2.Show();
                        this.Hide();
                        return;
                    }
                    else
                    {
                        // Проверяем, существует ли пользователь с таким логином
                        string checkQuery = "SELECT COUNT(*) FROM Клиенты WHERE Логин = @Login";
                        using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                        {
                            checkCommand.Parameters.AddWithValue("@Login", login);
                            int userCount = (int)checkCommand.ExecuteScalar();

                            if (userCount == 0)
                            {
                                // Создаем нового пользователя с ролью "Client"
                                string insertQuery = "INSERT INTO Клиенты (ФИО, Номер_телефона, Email, Логин, Пароль, Роль) VALUES (@ФИО, @Номер_телефона, @Email, @Логин, @Пароль, @Роль)";
                                using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                                {
                                    insertCommand.Parameters.AddWithValue("@ФИО", "Новый клиент");
                                    insertCommand.Parameters.AddWithValue("@Номер_телефона", "");
                                    insertCommand.Parameters.AddWithValue("@Email", "");
                                    insertCommand.Parameters.AddWithValue("@Логин", login);
                                    insertCommand.Parameters.AddWithValue("@Пароль", password);
                                    insertCommand.Parameters.AddWithValue("@Роль", "Client");

                                    insertCommand.ExecuteNonQuery();
                                }

                                UserManager.SetCurrentUser(login, "Client");

                                MessageBox.Show("Вы успешно зарегистрированы! Добро пожаловать!", "Успешная регистрация", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                Form2 form2 = new Form2();
                                form2.Show();
                                this.Hide();
                                return;
                            }
                            else
                            {
                                MessageBox.Show("Неверный логин или пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }
                    }
                }
            }
        }
    }
}