﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form9 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form9()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void LoadData()
        {
            string currentUser = UserManager.CurrentUser.Username;

            string query = "SELECT * FROM Клиенты WHERE Логин = @Логин";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Логин", currentUser);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox10.Text = reader["ID_клиента"].ToString();
                            textBox11.Text = reader["ФИО"].ToString();
                            textBox12.Text = reader["Номер_телефона"].ToString();
                            textBox9.Text = reader["Email"].ToString();
                            textBox13.Text = reader["Логин"].ToString();
                            textBox8.Text = reader["Пароль"].ToString();
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Клиенты SET ФИО = @ФИО, Номер_телефона = @Номер_телефона, Email = @Email, Логин = @Логин, Пароль = @Пароль  WHERE ID_клиента = @ID_клиента";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_клиента", int.Parse(textBox10.Text));
                    command.Parameters.AddWithValue("@ФИО", textBox11.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox12.Text);
                    command.Parameters.AddWithValue("@Email", textBox9.Text);
                    command.Parameters.AddWithValue("@Логин", textBox13.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox8.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Информация успешно сохранена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void спектаклиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
