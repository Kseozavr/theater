﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form8 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form8()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle; // или FormBorderStyle.Fixed3D;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;

            // Сделать textBox1 неизменяемым
            textBox6.ReadOnly = true;

        }
        private void LoadData()
        {
            string currentUser = UserManager.CurrentUser.Username;

            string query = "SELECT * FROM Управленцы WHERE Логин = @Логин";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Логин", currentUser);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox10.Text = reader["ID_работник"].ToString();
                            textBox11.Text = reader["ФИО"].ToString();
                            textBox12.Text = reader["Должность"].ToString();
                            textBox9.Text = reader["Номер_телефона"].ToString();
                            textBox13.Text = reader["Email"].ToString();
                            textBox8.Text = reader["Логин"].ToString();
                            textBox7.Text = reader["Пароль"].ToString();
                            textBox6.Text = reader["Роль"].ToString();
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Управленцы SET ФИО = @ФИО, Должность = @Должность, Номер_телефона = @Номер_телефона, Email = @Email, Логин = @Логин, Пароль = @Пароль, Роль = @Роль WHERE ID_работник = @ID_работник";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_работник", int.Parse(textBox10.Text));
                    command.Parameters.AddWithValue("@ФИО", textBox11.Text);
                    command.Parameters.AddWithValue("@Должность", textBox12.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox9.Text);
                    command.Parameters.AddWithValue("@Email", textBox13.Text);
                    command.Parameters.AddWithValue("@Логин", textBox8.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox7.Text);
                    command.Parameters.AddWithValue("@Роль", textBox6.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Информация успешно сохранена.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void жанрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }

        private void спектаклиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
