﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp2
{
    public partial class Form6 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form6()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;

            // Устанавливаем значение по умолчанию
            textBox3.Text = "Client";
            textBox4.Text = "Client";
            textBox10.Text = "Client";

            // Делаем текстовые поля нередактируемыми
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox10.ReadOnly = true;
        }

        private void LoadData()
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                tabControl3.Hide();
            }
            if (currentRole != "Admin")
            {
                tabControl3.Hide();
            }

            string query = "SELECT * FROM Клиенты";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;

                // Скрываем столбцы "Логин" и "Пароль" для пользователей с ролью "Kassir"
                if (currentRole == "Kassir")
                {
                    dataGridView1.Columns["Логин"].Visible = false;
                    dataGridView1.Columns["Пароль"].Visible = false;
                }
            }
        }

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void жанрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Клиенты (ФИО, Номер_телефона, Email, Логин, Пароль, Роль, ID_билета) VALUES (@ФИО, @Номер_телефона, @Email, @Логин, @Пароль, @Роль, @ID_билета)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ФИО", textBox28.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox34.Text);
                    command.Parameters.AddWithValue("@Email", textBox35.Text);
                    command.Parameters.AddWithValue("@Логин", textBox2.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox1.Text);
                    command.Parameters.AddWithValue("@Роль", textBox3.Text);
                    command.Parameters.AddWithValue("@ID_билета", textBox22.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Клиенты SET ФИО = @ФИО, Номер_телефона = @Номер_телефона, Email = @Email, Логин = @Логин, Пароль = @Пароль, Роль = @Роль, ID_билета = @ID_билета WHERE ID_клиента = @ID_клиента";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_клиента", int.Parse(textBox7.Text));
                    command.Parameters.AddWithValue("@ФИО", textBox8.Text);
                    command.Parameters.AddWithValue("@Номер_телефона", textBox9.Text);
                    command.Parameters.AddWithValue("@Email", textBox15.Text);
                    command.Parameters.AddWithValue("@Логин", textBox6.Text);
                    command.Parameters.AddWithValue("@Пароль", textBox5.Text);
                    command.Parameters.AddWithValue("@Роль", textBox4.Text);
                    command.Parameters.AddWithValue("@ID_билета", textBox23.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Клиенты WHERE ID_клиента = @ID_клиента";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_клиента", int.Parse(textBox32.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void FilterDataByClient()
        {
            string filterValueID = textBox13.Text.Trim();
            string filterValueFIO = textBox14.Text.Trim();
            string filterValuePhoneNumber = textBox16.Text.Trim();
            string filterValueEmail = textBox17.Text.Trim();
            string filterValueLogin = textBox12.Text.Trim();
            string filterValuePassword = textBox11.Text.Trim(); // Добавлен фильтр для пароля
            string filterValueRole = textBox10.Text.Trim();
            string filterValueTicketID = textBox21.Text.Trim();

            string query = @"SELECT * FROM Клиенты WHERE 1=1";

            if (!string.IsNullOrEmpty(filterValueID) && int.TryParse(filterValueID, out int id))
            {
                query += $" AND ID_клиента = {id}";
            }

            if (!string.IsNullOrEmpty(filterValueFIO))
            {
                query += $" AND ФИО LIKE '%{filterValueFIO}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePhoneNumber))
            {
                query += $" AND Номер_телефона LIKE '%{filterValuePhoneNumber}%'";
            }

            if (!string.IsNullOrEmpty(filterValueEmail))
            {
                query += $" AND Email LIKE '%{filterValueEmail}%'";
            }

            if (!string.IsNullOrEmpty(filterValueLogin))
            {
                query += $" AND Логин LIKE '%{filterValueLogin}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePassword))
            {
                query += $" AND Пароль LIKE '%{filterValuePassword}%'";
            }

            if (!string.IsNullOrEmpty(filterValueRole))
            {
                query += $" AND Роль LIKE '%{filterValueRole}%'";
            }

            if (!string.IsNullOrEmpty(filterValueTicketID) && int.TryParse(filterValueTicketID, out int ticketID))
            {
                query += $" AND ID_билета = {ticketID}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;

                // Скрываем столбцы "Логин" и "Пароль" для пользователей с ролью "Kassir"
                if (UserManager.CurrentUser.Role == "Kassir")
                {
                    dataGridView1.Columns["Логин"].Visible = false;
                    dataGridView1.Columns["Пароль"].Visible = false;
                }
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            FilterDataByClient();
        }

        private void личныйКабинетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
