﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form4 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form4()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void LoadData()
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole != "Admin" && currentRole != "Kassir")
            {
                tabControl7.Hide();
            }

            string query = "SELECT * FROM Билеты";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Билеты (ID_спектакля, Номер_места, Статус_билета, Цена_билета, Дата_покупки_бронирования, ID_клиента, ID_работник) VALUES (@ID_спектакля, @Номер_места, @Статус_билета, @Цена_билета, @Дата_покупки_бронирования, @ID_клиента, @ID_работник)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox28.Text));
                    command.Parameters.AddWithValue("@Номер_места", int.Parse(textBox34.Text));
                    command.Parameters.AddWithValue("@Статус_билета", comboBox3.Text);
                    command.Parameters.AddWithValue("@Цена_билета", int.Parse(textBox35.Text));
                    command.Parameters.AddWithValue("@Дата_покупки_бронирования", dateTimePicker2.Value);
                    command.Parameters.AddWithValue("@ID_клиента", textBox2.Text);
                    command.Parameters.AddWithValue("@ID_работник", int.Parse(textBox3.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Билеты SET ID_спектакля = @ID_спектакля, Номер_места = @Номер_места, Статус_билета = @Статус_билета, Цена_билета = @Цена_билета, Дата_покупки_бронирования = @Дата_покупки_бронирования, ID_клиента = @ID_клиента, ID_работник = @ID_работник WHERE ID_билета = @ID_билета";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_билета", int.Parse(textBox8.Text));
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox9.Text));
                    command.Parameters.AddWithValue("@Номер_места", int.Parse(textBox10.Text));
                    command.Parameters.AddWithValue("@Статус_билета", comboBox1.Text);
                    command.Parameters.AddWithValue("@Цена_билета", int.Parse(textBox11.Text));
                    command.Parameters.AddWithValue("@Дата_покупки_бронирования", dateTimePicker3.Value);
                    command.Parameters.AddWithValue("@ID_клиента", int.Parse(textBox5.Text));
                    command.Parameters.AddWithValue("@ID_работник", int.Parse(textBox4.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Билеты WHERE ID_билета = @ID_билета";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_билета", int.Parse(textBox32.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void FilterDataByTicket()
        {
            string filterValueID = textBox16.Text.Trim();
            string filterValueSpectacleID = textBox17.Text.Trim();
            string filterValueSeatNumber = textBox18.Text.Trim();
            string filterValueStatus = comboBox2.Text.Trim(); // Используем ComboBox для статуса
            string filterValuePrice = textBox19.Text.Trim();
            string filterValuePurchaseDate = textBox1.Text.Trim(); // Используем TextBox для даты
            string filterValueClientID = textBox13.Text.Trim();
            string filterValueWorkerID = textBox12.Text.Trim();

            string query = @"SELECT * FROM Билеты WHERE 1=1";

            if (!string.IsNullOrEmpty(filterValueID) && int.TryParse(filterValueID, out int id))
            {
                query += $" AND ID_билета = {id}";
            }

            if (!string.IsNullOrEmpty(filterValueSpectacleID) && int.TryParse(filterValueSpectacleID, out int spectacleID))
            {
                query += $" AND ID_спектакля = {spectacleID}";
            }

            if (!string.IsNullOrEmpty(filterValueSeatNumber) && int.TryParse(filterValueSeatNumber, out int seatNumber))
            {
                query += $" AND Номер_места = {seatNumber}";
            }

            if (!string.IsNullOrEmpty(filterValueStatus))
            {
                query += $" AND Статус_билета LIKE '%{filterValueStatus}%'";
            }

            if (!string.IsNullOrEmpty(filterValuePrice) && decimal.TryParse(filterValuePrice, out decimal price))
            {
                query += $" AND Цена_билета = {price}";
            }

            if (!string.IsNullOrEmpty(filterValuePurchaseDate) && DateTime.TryParse(filterValuePurchaseDate, out DateTime purchaseDate))
            {
                query += $" AND Дата_покупки_бронирования = '{purchaseDate:yyyy-MM-dd HH:mm:ss}'";
            }

            if (!string.IsNullOrEmpty(filterValueClientID) && int.TryParse(filterValueClientID, out int clientID))
            {
                query += $" AND ID_клиента = {clientID}";
            }

            if (!string.IsNullOrEmpty(filterValueWorkerID) && int.TryParse(filterValueWorkerID, out int workerID))
            {
                query += $" AND ID_работник = {workerID}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FilterDataByTicket();
        }

        private void личныйКабинетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
