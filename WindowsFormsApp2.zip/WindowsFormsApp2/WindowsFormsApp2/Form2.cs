﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;

            // Скрытие кнопок в зависимости от роли пользователя
            string currentRole = UserManager.CurrentUser.Role;
            if (currentRole == "Client")
            {
                button1.Visible = false;
                button2.Visible = false;
                button3.Visible = false;
                button4.Visible = false;
            }
            else if (currentRole == "Kassir")
            {
                button1.Visible = false;
                button3.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client" || currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Form3 frm = new Form3();
            this.Hide();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Form4 frm = new Form4();
            this.Hide();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client" || currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            Form5 frm = new Form5();
            this.Hide();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form6 frm = new Form6();
            this.Hide();
            frm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form7 frm = new Form7();
            this.Hide();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
