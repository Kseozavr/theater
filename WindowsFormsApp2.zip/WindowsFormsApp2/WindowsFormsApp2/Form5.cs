﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form5()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void LoadData()
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole != "Admin" && currentRole != "Kassir")
            {
                tabControl3.Hide();
            }

            string query = "SELECT * FROM Отчеты";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void жанрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form7 form = new Form7();
            form.Show();
            this.Hide();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Отчеты (ID_спектакля, Дата_отчета, Количество_проданных_билетов, Количество_забронированных_билетов, Общая_посещаемость, Создатель_отчета) VALUES (@ID_спектакля, @Дата_отчета, @Количество_проданных_билетов, @Количество_забронированных_билетов, @Общая_посещаемость, @Создатель_отчета)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox28.Text));
                    command.Parameters.AddWithValue("@Дата_отчета", dateTimePicker1.Value);
                    command.Parameters.AddWithValue("@Количество_проданных_билетов", int.Parse(textBox33.Text));
                    command.Parameters.AddWithValue("@Количество_забронированных_билетов", int.Parse(textBox35.Text));
                    command.Parameters.AddWithValue("@Общая_посещаемость", int.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Создатель_отчета", int.Parse(textBox2.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Отчеты SET ID_спектакля = @ID_спектакля, Дата_отчета = @Дата_отчета, Количество_проданных_билетов = @Количество_проданных_билетов, Количество_забронированных_билетов = @Количество_забронированных_билетов, Общая_посещаемость = @Общая_посещаемость, Создатель_отчета = @Создатель_отчета WHERE ID_отчета = @ID_отчета";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_отчета", int.Parse(textBox6.Text));
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox7.Text));
                    command.Parameters.AddWithValue("@Дата_отчета", dateTimePicker2.Value);
                    command.Parameters.AddWithValue("@Количество_проданных_билетов", int.Parse(textBox5.Text));
                    command.Parameters.AddWithValue("@Количество_забронированных_билетов", int.Parse(textBox9.Text));
                    command.Parameters.AddWithValue("@Общая_посещаемость", int.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@Создатель_отчета", int.Parse(textBox3.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Отчеты WHERE ID_отчета = @ID_отчета";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_отчета", int.Parse(textBox32.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void FilterDataByReport()
        {
            string filterValueID = textBox13.Text.Trim();
            string filterValueSpectacleID = textBox14.Text.Trim();
            string filterValueReportDate = textBox8.Text.Trim(); // Используем TextBox для даты
            string filterValueSoldTickets = textBox12.Text.Trim();
            string filterValueBookedTickets = textBox16.Text.Trim();
            string filterValueTotalAttendance = textBox11.Text.Trim();
            string filterValueCreatorID = textBox10.Text.Trim();

            string query = @"SELECT * FROM Отчеты WHERE 1=1";

            if (!string.IsNullOrEmpty(filterValueID) && int.TryParse(filterValueID, out int id))
            {
                query += $" AND ID_отчета = {id}";
            }

            if (!string.IsNullOrEmpty(filterValueSpectacleID) && int.TryParse(filterValueSpectacleID, out int spectacleID))
            {
                query += $" AND ID_спектакля = {spectacleID}";
            }

            if (!string.IsNullOrEmpty(filterValueReportDate) && DateTime.TryParse(filterValueReportDate, out DateTime reportDate))
            {
                query += $" AND Дата_отчета = '{reportDate:yyyy-MM-dd}'";
            }

            if (!string.IsNullOrEmpty(filterValueSoldTickets) && int.TryParse(filterValueSoldTickets, out int soldTickets))
            {
                query += $" AND Количество_проданных_билетов = {soldTickets}";
            }

            if (!string.IsNullOrEmpty(filterValueBookedTickets) && int.TryParse(filterValueBookedTickets, out int bookedTickets))
            {
                query += $" AND Количество_забронированных_билетов = {bookedTickets}";
            }

            if (!string.IsNullOrEmpty(filterValueTotalAttendance) && int.TryParse(filterValueTotalAttendance, out int totalAttendance))
            {
                query += $" AND Общая_посещаемость = {totalAttendance}";
            }

            if (!string.IsNullOrEmpty(filterValueCreatorID) && int.TryParse(filterValueCreatorID, out int creatorID))
            {
                query += $" AND Создатель_отчета = {creatorID}";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FilterDataByReport();
        }

        private void личныйКабинетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
