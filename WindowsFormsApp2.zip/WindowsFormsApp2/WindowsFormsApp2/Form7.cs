﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form7 : Form
    {
        string connectionString = @"Data Source=LAPTOP-Q7DU6KTJ;Initial catalog=театр;Integrated Security=True";
        public Form7()
        {
            InitializeComponent();
            LoadData();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void LoadData()
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client")
            {
                tabControl3.Hide();
            }
            else if (currentRole == "Admin" || currentRole == "Kassir")
            {
                tabControl3.Show();
            }
            string query = "SELECT * FROM Спектакли";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void книгиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir" || currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void жанрыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form4 form = new Form4();
            form.Show();
            this.Hide();
        }

        private void авторыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Kassir" || currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Client")
            {
                MessageBox.Show("У вас нет доступа к этой форме.", "Ошибка доступа", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Form6 form = new Form6();
            form.Show();
            this.Hide();
        }

        private void главноеМенюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void выйтиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы действительно хотите выйти из приложения?", "Подтверждение выхода", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Спектакли (Название_спектакля, Дата_и_время_проведения, Место_проведения, Описание_спектакля, Стоимость_билетов, Актеры) VALUES (@Название_спектакля, @Дата_и_время_проведения, @Место_проведения, @Описание_спектакля, @Стоимость_билетов, @Актеры)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Название_спектакля", textBox28.Text);
                    command.Parameters.AddWithValue("@Дата_и_время_проведения", dateTimePicker1.Value);
                    command.Parameters.AddWithValue("@Место_проведения", textBox35.Text);
                    command.Parameters.AddWithValue("@Описание_спектакля", richTextBox4.Text);
                    command.Parameters.AddWithValue("@Стоимость_билетов", int.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Актеры", richTextBox1.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Спектакли SET Название_спектакля = @Название_спектакля, Дата_и_время_проведения = @Дата_и_время_проведения, Место_проведения = @Место_проведения, Описание_спектакля = @Описание_спектакля, Стоимость_билетов = @Стоимость_билетов, Актеры = @Актеры WHERE ID_спектакля = @ID_спектакля";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox3.Text));
                    command.Parameters.AddWithValue("@Название_спектакля", textBox4.Text);
                    command.Parameters.AddWithValue("@Дата_и_время_проведения", dateTimePicker2.Value);
                    command.Parameters.AddWithValue("@Место_проведения", textBox5.Text);
                    command.Parameters.AddWithValue("@Описание_спектакля", richTextBox2.Text);
                    command.Parameters.AddWithValue("@Стоимость_билетов", int.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@Актеры", richTextBox5.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button21_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Спектакли WHERE ID_спектакля = @ID_спектакля";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID_спектакля", int.Parse(textBox32.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void FilterDataByShow()
        {
            string filterValueID = textBox11.Text.Trim();
            string filterValueShowName = textBox12.Text.Trim();
            string filterValueShowDateTime = textBox6.Text.Trim(); // Используем TextBox для даты и времени
            string filterValueShowLocation = textBox14.Text.Trim();
            string filterValueShowDescription = richTextBox6.Text.Trim();
            string filterValueTicketPrice = textBox9.Text.Trim();
            string filterValueActors = richTextBox3.Text.Trim();

            string query = @"SELECT * FROM Спектакли WHERE 1=1";

            if (!string.IsNullOrEmpty(filterValueID) && int.TryParse(filterValueID, out int id))
            {
                query += $" AND ID_спектакля = {id}";
            }

            if (!string.IsNullOrEmpty(filterValueShowName))
            {
                query += $" AND Название_спектакля LIKE '%{filterValueShowName}%'";
            }

            if (!string.IsNullOrEmpty(filterValueShowDateTime) && DateTime.TryParse(filterValueShowDateTime, out DateTime showDateTime))
            {
                query += $" AND Дата_и_время_проведения = '{showDateTime:yyyy-MM-dd HH:mm:ss}'";
            }

            if (!string.IsNullOrEmpty(filterValueShowLocation))
            {
                query += $" AND Место_проведения LIKE '%{filterValueShowLocation}%'";
            }

            if (!string.IsNullOrEmpty(filterValueShowDescription))
            {
                query += $" AND Описание_спектакля LIKE '%{filterValueShowDescription}%'";
            }

            if (!string.IsNullOrEmpty(filterValueTicketPrice) && decimal.TryParse(filterValueTicketPrice, out decimal price))
            {
                query += $" AND Стоимость_билетов = {price}";
            }

            if (!string.IsNullOrEmpty(filterValueActors))
            {
                query += $" AND Актеры LIKE '%{filterValueActors}%'";
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            FilterDataByShow();
        }

        private void личныйКабинетToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string currentRole = UserManager.CurrentUser.Role;

            if (currentRole == "Admin" || currentRole == "Kassir")
            {
                Form8 form8 = new Form8();
                form8.Show();
                this.Hide();
            }
            else if (currentRole == "Client")
            {
                Form9 form9 = new Form9();
                form9.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неизвестная роль пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
